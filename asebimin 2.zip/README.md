# Asebi Mincho

[馬酔木明朝](https://metasta.github.io/asebi/)は以下のフォントを合成して作られた旧字明朝体フォントです。
- IPAmj明朝 - 旧字（約2000字）
- 三番明朝 - 旧字以外の漢字
- 愛宕明朝 - かな、英数字、記号類

[IPAmj明朝](http://mojikiban.ipa.go.jp/1300.html)
[三番明朝](http://www.akenotsuki.com/eyeben/fonts/sammin.html)
[愛宕明朝](http://www.akenotsuki.com/eyeben/font/otagi.html)

## License

IPAフォントライセンスv1.0 のもとで配布します。  
IPA_Font_License_Agreement_v1.0.txt または  
http://ipafont.ipa.go.jp/ipa_font_license_v1.html を参照してください。

※IPAex明朝／IPAmj明朝に戻す方法 (IPAフォントライセンスv1.0 第3条1項 (2))
…  
[IPAex明朝](http://ipafont.ipa.go.jp)
もしくは
[IPAmj明朝](http://mojikiban.ipa.go.jp/1300.html)
をダウンロードし、インストールしてください。

## Changelog

[asebi README](https://github.com/metasta/asebi/blob/master/README.md#changelog)
を参照してください。
